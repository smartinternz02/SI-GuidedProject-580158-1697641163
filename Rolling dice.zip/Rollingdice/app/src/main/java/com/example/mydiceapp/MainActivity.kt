// src/main/java/com.example.mydiceapp/MainActivity.kt
package com.example.mydiceapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var btnRoll: Button
    private lateinit var tvResult: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnRoll = findViewById(R.id.btnRoll)
        tvResult = findViewById(R.id.tvResult)

        btnRoll.setOnClickListener {
            rollDice()
        }
    }

    @SuppressLint("SetTextI18n")
    private fun rollDice() {
        val random = Random()
        val diceValue = random.nextInt(6) + 1 // 1 to 6 inclusive

        // Show the result
        tvResult.text = "Result: $diceValue"
    }
}
